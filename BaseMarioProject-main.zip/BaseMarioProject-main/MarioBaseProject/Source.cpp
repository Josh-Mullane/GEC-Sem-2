//Be grateful for humble beginnings, because the next level will always require so much more of you

int main(int argc, char* args[])
{
	return 0;
}